﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;
using System.Configuration;
using System.Text;

namespace VandenboscheRepair.Controllers
{
    public class AdminsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        private bool UsernameAlreadyExists(String username)
        {
            IQueryable<Admin> ad = from Admins in db.Admins where Admins.Username == username select Admins;
            if (ad.FirstOrDefault() == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        // GET: Dashboard
        public ActionResult Index()
        {
            if (Validated())
            {
                Session["ItemTypes"] = new SelectList(ConfigurationManager.AppSettings["ItemType"].Split(';'));
                Session["JobTypes"] = new SelectList(ConfigurationManager.AppSettings["JobType"].Split(';'));
                Session["Statuses"] = new SelectList(ConfigurationManager.AppSettings["Status"].Split(';'));
                
                //number of logs
                Session["numberLogs"] = db.Logs.ToList().FindAll(x => x.MarkedRead == false).Count;

                //number of appointments
                Session["numberAppointments"] = db.Appointments.ToList().FindAll(x => x.Archived == false).Count;
                
                //number of feedbacks
                Session["numberFeedbacks"] = db.Feedbacks.ToList().FindAll(x => x.markRead == false).Count;

                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        public ActionResult Reports()
        {
            if (Validated())
            {
                //create all reports data and return view

                //code for jobs status
                string[] jobStatusVals = ConfigurationManager.AppSettings["Status"].Split(';');
                for (int i = 0; i < jobStatusVals.Count() - 1; i++)
                {
                    jobStatusVals[i] += ";" + db.Jobs.ToList().FindAll(x => x.Status == jobStatusVals[i]).Count;
                }
                Session["jobStatusVals"] = jobStatusVals;

                //code for overdue jobs
                List<Job> jobsOverdue = (db.Jobs.ToList().FindAll(x => x.DatePromised.Date <= DateTime.Today.Date)).OrderBy(x => x.DatePromised).ToList();

                string[] comingUp = new string[jobsOverdue.Count];

                for (int i = 0; i < jobsOverdue.Count; i++)
                {
                    comingUp[i] = Convert.ToString((int)(DateTime.Today - jobsOverdue[i].DatePromised).TotalDays) + " days";
                    comingUp[i] += ";<a href=\"/Jobs/Details/"+jobsOverdue[i].Id + "\">" + jobsOverdue[i].JobID+ "</a>";
                    comingUp[i] += ";" + jobsOverdue[i].Status;
                }
                Session["comingUp"] = comingUp;

                //code for third graph
                List<Job> next10Days = db.Jobs.ToList().FindAll(x => x.DatePromised > DateTime.Today && x.DatePromised <= x.DatePromised.AddDays(10));

                //create next 10 days array
                string[] days = new string[10];
                for (int i = 0; i < 10; i++)
                {
                    days[i] = "";
                }
                int[] daysVals = new int[10];
                if (next10Days.Count > 0)
                {
                    if (next10Days[0] != null)
                    {
                        //days - labels
                        for (int i = 0; i < 10; i++)
                        {
                            days[i] = Convert.ToString(DateTime.Today.AddDays(i + 1).Day + " " + DateTime.Today.AddDays(i + 1).ToString("MMM"));
                        }
                        //values - actual values
                        for (int i = 0; i < next10Days.Count; i++)
                        {
                            int ttlDays = Convert.ToInt32((next10Days[i].DatePromised - DateTime.Now).TotalDays);
                            switch (ttlDays)
                            {
                                case 0:
                                    daysVals[0] += 1;
                                    break;
                                case 1:
                                    daysVals[1] += 1;
                                    break;
                                case 2:
                                    daysVals[2] += 1;
                                    break;
                                case 3:
                                    daysVals[3] += 1;
                                    break;
                                case 4:
                                    daysVals[4] += 1;
                                    break;
                                case 5:
                                    daysVals[5] += 1;
                                    break;
                                case 6:
                                    daysVals[6] += 1;
                                    break;
                                case 7:
                                    daysVals[7] += 1;
                                    break;
                                case 8:
                                    daysVals[8] += 1;
                                    break;
                                case 9:
                                    daysVals[9] += 1;
                                    break;
                            }
                        }
                    }
                }
                
                StringBuilder sb1 = new StringBuilder();
                sb1.Append("<script>");
                sb1.Append("days = new Array;");
                foreach (string str in days)
                {
                    sb1.Append("days.push('" + str + "');");
                }
                sb1.Append("</script>");

                StringBuilder sb2 = new StringBuilder();
                sb2.Append("<script>");
                sb2.Append("daysVals = new Array;");
                foreach (int str in daysVals)
                {
                    sb2.Append("daysVals.push('" + str + "');");
                }
                sb2.Append("</script>");

                Session["days"] = sb1.ToString();
                Session["daysVals"] = sb2.ToString();

                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }


        // GET: Admins
        public ActionResult Manage()
        {
            if (Validated())
            {
                return View(db.Admins.ToList());
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Create
        public ActionResult Create()
        {
            if (Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Username,Password,StreetAddress,City,Province,PostalCode,Phone,Email,Type")] Admin admin)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    if (!UsernameAlreadyExists(admin.Username))
                    {
                        db.Admins.Add(admin);
                        db.SaveChanges();
                        return RedirectToAction("Manage");
                    }
                    else
                    {
                        ModelState.AddModelError("Username", "This username already exists.");
                    }
                }

                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Username,Password,StreetAddress,City,Province,PostalCode,Phone,Email,Type")] Admin admin)
        {
            if (Validated()) { 
                if (ModelState.IsValid)
                {
                        db.Entry(admin).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("Manage");
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                bool logoff = false;
                if (id == ((Admin)Session["adminLoggedIn"]).Id)
                {
                    logoff = true;
                }
                Admin admin = db.Admins.Find(id);
                db.Admins.Remove(admin);
                db.SaveChanges();
                if (logoff)
                {
                    Session["adminLoggedIn"] = null;
                    Session["invalidLoginAttempt"] = null;
                    return Redirect("/Home/");
                }
                return RedirectToAction("Manage");
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Logout()
        {
            Session["adminLoggedIn"] = null;
            Session["invalidLoginAttempt"] = null;
            Session["ItemTypes"] = null;
            Session["JobTypes"] = null;
            Session["Statuses"] = null;
            Session["numberLogs"] = null;
            return Redirect("/Home/");
        }
    }
}
