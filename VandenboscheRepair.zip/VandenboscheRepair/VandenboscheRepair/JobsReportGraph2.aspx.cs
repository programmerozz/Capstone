﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VandenboscheRepair.Models;
using Microsoft.Reporting.WebForms;
namespace VandenboscheRepair
{
    public partial class JobsReportGraph2 : System.Web.UI.Page
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();
        public string reportMessage { get; set; }
        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Validated())
            {
                if (!IsPostBack)
                {
                    RenderReport();
                    reportMessage = "";
                }
            }
            else
            {
                reportMessage = "Access Denied!";
                //return Redirect("/Home/AdminAuthentication");
            }
        }

        private void RenderReport()
        {

            List<VandenboscheRepair.Models.Job> jobs = null;
            using (VandenboscheRepair.Models.VandenboscheDBEntities dc = new VandenboscheRepair.Models.VandenboscheDBEntities())
            {

                jobs = dc.Jobs.OrderBy(a => a.JobID).ToList();
                ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/ReportsDesign/JobsReportGraph2.rdlc");
                ReportViewer1.LocalReport.DataSources.Clear();
                ReportDataSource rdc = new ReportDataSource("DataSetGraph2Jobs", jobs);
                ReportViewer1.LocalReport.DataSources.Add(rdc);
                ReportViewer1.LocalReport.Refresh();


            }
        }
    }
}