﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;
namespace VandenboscheRepair.Controllers
{
    public class ReportsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }
        // GET: Reports
        public ActionResult Index()
        {
            if (Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }

        }

    }
}
