﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using VandenboscheRepair.Models;
using System.Net;


namespace VandenboscheRepair.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult JobStatus()
        {
            try
            {
                Job j = (Job)Session["trackJob"];
                if (j == null)
                {
                    throw new Exception("Log-in to access this page.");
                }
                Session["trackJob"] = null;
                return View(j);
            }
            catch (Exception exp)
            {
                Session["trackJob"] = null;
                ViewBag.Message = "Log-in to access this page.";
                return Redirect("/Home/");
            }
        }

        public ActionResult Feedback()
        {
            return View();
        }

        [HttpPost]
        public ActionResult JobStatus([Bind(Include = "JobID,Instructions")] Job job)
        {
            VandenboscheDBEntities db = new VandenboscheDBEntities();
            Job j = db.Jobs.ToList().Find(x => x.JobID == job.JobID);
            if (j == null)
            {
                ViewBag.Message = "Forbidden";
                return Redirect("/Home/");
            }
            else if(job.Instructions.Length > 400)
            {
                Session["trackJob"] = j;
                return JobStatus();
            }
            else
            {
                Logs log = new Logs();
                log.CustomerFirstName = j.Customer.FirstName;
                log.CustomerLastName = j.Customer.LastName;
                log.MarkedRead = false;
                log.DateCreated = DateTime.Now;
                log.JobID = j.JobID;
                log.Old_instructions = j.Instructions;
                log.New_instructions = job.Instructions;
                db.Logs.Add(log);
                db.SaveChanges();
                j.Instructions = job.Instructions;
                db.Entry(j).State = EntityState.Modified;
                db.SaveChanges();
                return Redirect("/Home/");
            }
        }

        public ActionResult Index()
        {
            string test = (string)Session["message"];
            Session["message"] = test;
            ViewBag.Message = "Login using your Repair Number:";
            return View();
        }

        [HttpPost]
        public ActionResult Index([Bind(Include = "Phone,Email")] Customer customer,[Bind(Include ="JobID")] Job job)
        {
            if (customer.Phone == "" || customer.Email == "" || job.JobID == "")
            {
                return Redirect("/Home/");
            }
            VandenboscheDBEntities db = new VandenboscheDBEntities();
            Job j = db.Jobs.ToList().Find(x => x.JobID == job.JobID);
            if (j == null)
            {
                ViewBag.Message = "Invalid credentials";
                return View();
            }
            else
            {
                Customer c = j.Customer;
                if (customer.Phone == c.Phone && customer.Email == c.Email)
                {
                    Session["trackJob"] = j;
                    return Redirect("/Home/JobStatus/");
                }
                else {
                    ViewBag.Message = "Invalid credentials";
                }
                return View();
            }
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult Brands()
        {
            return View();
        }

        public ActionResult Contact(int? id)
        {
            if(id == null)
                return View();
            else
            {
                if (id == 1)
                {
                    Appointment apt = (Appointment)Session["apt"];
                    return View(apt);
                }
                else
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
        }

        [HttpGet]
        public ActionResult AdminAuthentication()
        {
            if(Session["invalidLoginAttempt"] != null)
            {
                Session["invalidLoginAttempt"] = null;
                ViewBag.Message = "Please log-in first to access the page";
            }
            else if (Session["adminLoggedIn"] != null)
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    VandenboscheDBEntities db = new VandenboscheDBEntities();
                    Admin a = db.Admins.ToList().Find(x => x.Username == ad.Username);
                    if (a == null)
                    {
                        ViewBag.Message = "Invalid Username";
                    }
                    else if (a.Password != ad.Password)
                    {
                        ViewBag.Message = "Invalid Password";
                    }
                    else if (a.Username == ad.Username && a.Password == ad.Password)
                    {
                        Session["adminLoggedIn"] = a;
                        return Redirect("/Admins/");
                    }
                }
                catch(Exception exp)
                {
                    ViewBag.Message = "Invalid session user. Please contact the Administrator!";
                }
            }
            return View();
        }

        [HttpPost]
        public ActionResult AdminAuthentication([Bind(Include = "Username,Password")] Admin admin)
        {
            if (admin.Username != null && admin.Password != null)
            {
                VandenboscheDBEntities db = new VandenboscheDBEntities();
                Admin a = db.Admins.ToList().Find(x => x.Username == admin.Username);
                if (a == null)
                {
                    ViewBag.Message = "Invalid Username";
                }
                else if (a.Password != admin.Password)
                {
                    ViewBag.Message = "Invalid Password";
                }
                else if (a.Username == admin.Username && a.Password == admin.Password)
                {
                    admin.Type = a.Type;
                    admin.Id = a.Id;
                    Session["adminLoggedIn"] = admin;
                    return Redirect("/Admins/Index");
                }
            }
            else
            {
                ViewBag.Message = "Please fill in both the username and the password";
            }
            return View();
        }
    }
}