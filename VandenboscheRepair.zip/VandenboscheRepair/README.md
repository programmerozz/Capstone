# Capstone
This is the capstone project that we have developed in 2016. The team had four members and my role was the programmer. 
We have developed this application to help local jewellery store to improve their daily production. 
Technologies that we used are; ASP.Net MVC, C#, HTML5, CSS3, Bootstrap, JQuery, Entity Framework.



