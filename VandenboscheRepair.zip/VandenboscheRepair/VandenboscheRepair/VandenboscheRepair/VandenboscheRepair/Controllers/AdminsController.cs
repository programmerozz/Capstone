﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;
using System.Configuration;

namespace VandenboscheRepair.Controllers
{
    public class AdminsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        private bool UsernameAlreadyExists(String username)
        {
            IQueryable<Admin> ad = from Admins in db.Admins where Admins.Username == username select Admins;
            if (ad.FirstOrDefault() == null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        // GET: Dashboard
        public ActionResult Index()
        {
            if (Validated())
            {
                Session["ItemTypes"] = new SelectList(ConfigurationManager.AppSettings["ItemType"].Split(';'));
                Session["JobTypes"] = new SelectList(ConfigurationManager.AppSettings["JobType"].Split(';'));
                Session["Statuses"] = new SelectList(ConfigurationManager.AppSettings["Status"].Split(';'));
                
                //number of logs
                Session["numberLogs"] = db.Logs.ToList().FindAll(x => x.MarkedRead == false).Count;

                //number of appointments
                Session["numberAppointments"] = db.Appointments.ToList().FindAll(x => x.Archived == false).Count;
                
                //number of feedbacks
                Session["numberFeedbacks"] = db.Feedbacks.ToList().FindAll(x => x.markRead == false).Count;

                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        public ActionResult Reports()
        {
            if (Validated())
            {
                //create all reports data and return view

                //code for jobs status
                string[] jobStatusVals = ConfigurationManager.AppSettings["Status"].Split(';');
                for (int i = 0; i < jobStatusVals.Count() - 1; i++)
                {
                    jobStatusVals[i] += ";" + db.Jobs.ToList().FindAll(x => x.Status == jobStatusVals[i]).Count;
                }
                Session["jobStatusVals"] = jobStatusVals;

                //code for overdue jobs
                List<Job> jobsOverdue = (db.Jobs.ToList().FindAll(x => x.DatePromised.Date <= DateTime.Today.Date)).OrderBy(x => x.DatePromised).ToList();

                string[] comingUp = new string[jobsOverdue.Count];

                for (int i = 0; i < jobsOverdue.Count; i++)
                {
                    comingUp[i] = jobsOverdue[i].DatePromised.Date.ToString("dd/MM/yyyy");
                    comingUp[i] += ";" + jobsOverdue[i].JobID;
                    comingUp[i] += ";" + jobsOverdue[i].Status;
                }
                Session["comingUp"] = comingUp;

                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }


        // GET: Admins
        public ActionResult Manage()
        {
            if (Validated())
            {
                return View(db.Admins.ToList());
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Create
        public ActionResult Create()
        {
            if (Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,Username,Password,StreetAddress,City,Province,PostalCode,Phone,Email,Type")] Admin admin)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    if (!UsernameAlreadyExists(admin.Username))
                    {
                        db.Admins.Add(admin);
                        db.SaveChanges();
                        return RedirectToAction("Manage");
                    }
                    else
                    {
                        ModelState.AddModelError("Username", "This username already exists.");
                    }
                }

                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,Username,Password,StreetAddress,City,Province,PostalCode,Phone,Email,Type")] Admin admin)
        {
            if (Validated()) { 
                if (ModelState.IsValid)
                {
                        db.Entry(admin).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("Manage");
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Admins/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Admin admin = db.Admins.Find(id);
                if (admin == null)
                {
                    return HttpNotFound();
                }
                return View(admin);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Admins/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                bool logoff = false;
                if (id == ((Admin)Session["adminLoggedIn"]).Id)
                {
                    logoff = true;
                }
                Admin admin = db.Admins.Find(id);
                db.Admins.Remove(admin);
                db.SaveChanges();
                if (logoff)
                {
                    Session["adminLoggedIn"] = null;
                    Session["invalidLoginAttempt"] = null;
                    return Redirect("/Home/");
                }
                return RedirectToAction("Manage");
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult Logout()
        {
            Session["adminLoggedIn"] = null;
            Session["invalidLoginAttempt"] = null;
            Session["ItemTypes"] = null;
            Session["JobTypes"] = null;
            Session["Statuses"] = null;
            Session["numberLogs"] = null;
            return Redirect("/Home/");
        }
    }
}
