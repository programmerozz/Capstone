﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;

namespace VandenboscheRepair.Controllers
{
    public class LogsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        // GET: Logs
        public ActionResult Index()
        {
            if (Validated())
            {
                return View(db.Logs.ToList().FindAll(x=> x.MarkedRead == false));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        public ActionResult ViewLogs()
        {
            if (Validated())
            {
                return View(db.Logs.ToList().FindAll(x => x.MarkedRead == true));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        public ActionResult MarkAsRead(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Logs logs = db.Logs.Find(id);
            if (logs == null)
            {
                return HttpNotFound();
            }
            if (logs.MarkedRead)
            {
                logs.MarkedRead = false;
            }
            else
            {
                logs.MarkedRead = true;
            }
            db.SaveChanges();
            Session["numberLogs"] = db.Logs.ToList().FindAll(x => x.MarkedRead == false).Count;
            return Redirect("/Logs/");
        }

        // GET: Logs/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Logs logs = db.Logs.Find(id);
                if (logs == null)
                {
                    return HttpNotFound();
                }
                return View(logs);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
