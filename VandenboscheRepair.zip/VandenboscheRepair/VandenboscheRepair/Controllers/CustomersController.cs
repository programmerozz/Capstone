﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;

namespace VandenboscheRepair.Controllers
{
    public class CustomersController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        // GET: Customers
        public ActionResult Index()
        {
            if (Validated()) {
                return View(db.Customers.ToList());
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Customers/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Customers/Create
        public ActionResult Create()
        {
            if (Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        private bool checkDuplicate(Customer c)
        {
            List<Customer> list = db.Customers.ToList();
            if ((from customer in list
                 where customer.City == c.City &&
                 customer.Email == c.Email &&
                 customer.FirstName == c.FirstName &&
                 customer.LastName == c.LastName &&
                 customer.Phone == c.Phone &&
                 customer.PostalCode == c.PostalCode &&
                 customer.Province == c.Province &&
                 customer.StreetAddress == c.StreetAddress
                 select customer).FirstOrDefault() != null) { return true; } else
            {
                return false;
            }
          
        }

        // POST: Customers/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,FirstName,LastName,StreetAddress,City,Province,PostalCode,Phone,Email")] Customer customer)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    if (checkDuplicate(customer) == false)
                    {
                        db.Customers.Add(customer);
                        db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.Message = "Customer already exists";
                        return View(customer);
                    }
                }
                return View(customer);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Customers/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Customers/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,FirstName,LastName,StreetAddress,City,Province,PostalCode,Phone,Email")] Customer customer)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    db.Entry(customer).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(customer);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Customers/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Customer customer = db.Customers.Find(id);
                if (customer == null)
                {
                    return HttpNotFound();
                }
                return View(customer);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                try {
                    Customer customer = db.Customers.Find(id);
                    db.Customers.Remove(customer);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                catch(Exception exp)
                {
                    Customer customer = db.Customers.Find(id);
                    Session["errorCustName"] = customer.FirstName;
                    List<Job> jbs = (from item in db.Jobs where item.Customers_Id == id select item).ToList();
                    Session["errorJobs"] = jbs;
                    return RedirectToAction("Error");
                }
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        [ActionName("Error")]
        public ActionResult Error()
        {
            if(Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
