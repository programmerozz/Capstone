﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;

namespace VandenboscheRepair.Controllers
{
    public class AppointmentsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        // GET: Appointments
        public ActionResult Index()
        {
            if (Validated())
            {
                return View(db.Appointments.ToList().FindAll(x=>x.Archived == false));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Finished Appointments
        public ActionResult FinishedAppointments()
        {
            if(Validated())
            {
                return View(db.Appointments.ToList().FindAll(x => x.Archived == true));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Appointments/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Appointment appointment = db.Appointments.Find(id);
                if (appointment == null)
                {
                    return HttpNotFound();
                }
                return View(appointment);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Appointments/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Name,Email,Phone,Message,Date")] Appointment appointment, [Bind(Include ="file")]HttpPostedFileBase file)
        {
            if (ModelState.IsValid)
            {
                if (file != null)
                {
                    if (file.ContentType.Split('/')[0] == "image")
                    {
                        int picId = 1;
                        try
                        {
                            picId = db.Appointments.Max(x => x.Id) + 1;
                        }
                        catch (InvalidOperationException exp) { }
                        string fileName = System.IO.Path.GetFileName("PIC" + picId + "." + file.ContentType.Split('/')[1]);
                        string path = System.IO.Path.Combine(Server.MapPath("~/Images"), fileName);
                        // file is uploaded
                        file.SaveAs(path);
                        //save file name
                        appointment.Picture = path;
                        db.Appointments.Add(appointment);
                        db.SaveChanges();
                        return RedirectToAction("Index","Home");
                    }
                    else
                    {
                        Session["validImage"] = "flag";
                        Session["apt"] = appointment;
                        return RedirectToAction("Contact", "Home", new { id = 1 });
                    }
                }
                else
                {
                    Session["message"] = "Your appointment has been requested. You will receive an email shortly from Vandenbosche confirming your appointment.";
                    db.Appointments.Add(appointment);
                    db.SaveChanges();
                    return RedirectToAction("Index","Home");
                }
            }
            return View("~/Views/Home/Contact.cshtml",appointment);
        }

        // GET: Appointments/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Appointment appointment = db.Appointments.Find(id);
                if (appointment == null)
                {
                    return HttpNotFound();
                }
                return View(appointment);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Appointments/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Name,Email,Phone,Message,Date,Archived")] Appointment appointment)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    db.Entry(appointment).State = EntityState.Modified;
                    db.Entry(appointment).Property(x => x.Picture).IsModified = false;
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Appointments/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Appointment appointment = db.Appointments.Find(id);
                if (appointment == null)
                {
                    return HttpNotFound();
                }
                return View(appointment);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Appointments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                Appointment appointment = db.Appointments.Find(id);
                if(appointment.Picture != null)
                {
                    //remove image
                    System.IO.File.Delete(appointment.Picture);
                }
                db.Appointments.Remove(appointment);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
