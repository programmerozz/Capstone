﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace VandenboscheRepair.Models
{
    public class AdminMetaData
    {
        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid Firstname")]
        [Display(Name ="First Name")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid Lastname")]
        [Display(Name ="Last Name")]
        public string LastName { get; set; }

        [Required]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "Invalid Username")]
        [Display(Name ="Username")]
        public string Username { get; set; }

        [Required]
        [StringLength(18, MinimumLength = 6, ErrorMessage = "Must be between 6 and 30 characters")]
        [RegularExpression(@".*[0-9].*[0-9].*", ErrorMessage = "Password must consist at least 2 numbers")]
        [DataType(DataType.Password)]
        [Display(Name ="Password")]
        public string Password { get; set; }

        [Required]
        [StringLength(60, MinimumLength = 2, ErrorMessage = "Invalid Street Address")]
        [Display(Name ="Street Address")]
        public string StreetAddress { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid City Name")]
        [Display(Name ="City")]
        public string City { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 2, ErrorMessage = "Invalid Province Name")]
        [Display(Name ="Province/State")]
        public string Province { get; set; }

        [Required]
        [RegularExpression(@"[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]", ErrorMessage = "Invalid Canadian Postal Code")]
        [Display(Name ="Postal Code")]
        public string PostalCode { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Not a valid Phone number")]
        [Display(Name ="Phone Number")]
        public string Phone { get; set; }

        [Required]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid Email")]
        [Display(Name ="Email Address")]
        public string Email { get; set; }

        [Required]
        [Display(Name ="Type")]
        public string Type { get; set; }
    }

    public class JobMetaData
    {
        [Required]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "JobID must consists of 5 characters")]
        [Display(Name ="JOB ID")]
        public string JobID { get; set; }

        [Required]
        [Display(Name ="Item Type")]
        public string ItemType { get; set; }

        [Required]
        [Display(Name ="Job Type")]
        public string JobType { get; set; }

        [Required]
        [Display(Name ="Job Status")]
        public string Status { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}",
               ApplyFormatInEditMode = true)]
        [Display(Name ="Date Promised")]
        public System.DateTime DatePromised { get; set; }

        [Required]
        [Display(Name ="Requirements")]
        [DataType(DataType.MultilineText)]
        [StringLength(400,ErrorMessage ="400 characters at maximum only")]
        public string Instructions { get; set; }

        [Required]
        [Range(0.0, double.MaxValue, ErrorMessage = "Positive numbers only")]
        [Display(Name ="$ Deposit")]
        public double Deposit { get; set; }

        [Required]
        [Range(0.0, double.MaxValue, ErrorMessage = "Positive numbers only")]
        [Display(Name ="$ Sub Total")]
        public string SubTotal { get; set; }
        [Required]
        [Range(0.0, double.MaxValue, ErrorMessage = "Positive numbers only")]
        [Display(Name ="$ HST/GST")]
        public string HstGst { get; set; }
        [Required]
        [Range(0.0, double.MaxValue, ErrorMessage = "Positive numbers only")]
        [Display(Name ="$ PST")]
        public string Pst { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}",
               ApplyFormatInEditMode = true)]
        [Display(Name ="Pickup Date")]
        public System.DateTime DatePickedUp { get; set; }

        [Required]
        public int Customers_Id { get; set; }

        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}",
               ApplyFormatInEditMode = true)]
        [Display(Name ="Received Date")]
        public System.DateTime DateReceived { get; set; }
    }

    public class CustomerMetaData
    {
        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid Firstname")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid Lastname")]
        public string LastName { get; set; }

        [Required]
        [StringLength(60, MinimumLength = 2, ErrorMessage = "Invalid Street Address")]
        public string StreetAddress { get; set; }

        [Required]
        [StringLength(30, MinimumLength = 2, ErrorMessage = "Invalid City Name")]
        public string City { get; set; }

        [Required]
        [StringLength(15, MinimumLength = 2, ErrorMessage = "Invalid Province Name")]
        public string Province { get; set; }

        [Required]
        [RegularExpression(@"[ABCEGHJKLMNPRSTVXY][0-9][ABCEGHJKLMNPRSTVWXYZ] ?[0-9][ABCEGHJKLMNPRSTVWXYZ][0-9]", ErrorMessage = "Invalid Canadian Postal Code")]
        public string PostalCode { get; set; }

        [Required]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Not a valid Phone number")]
        public string Phone { get; set; }

        [Required]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid Email")]
        public string Email { get; set; }
    }

    public class AppointmentMetaData
    {
        [Required]
        [MaxLength(20,ErrorMessage ="Name cannot be larger than 20 characters")]
        public string Name { get; set; }
        [Required]
        [RegularExpression(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$", ErrorMessage = "Invalid Email")]
        public string Email { get; set; }
        [Required]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Not a valid Phone number")]
        public string Phone { get; set; }
        [Required]
        [MaxLength(100,ErrorMessage ="Please provide brief summery about the appointment")]
        public string Message { get; set; }
        [Required]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}",
               ApplyFormatInEditMode = true)]
        public System.DateTime Date { get; set; }
        [Display(Name="Finished")]
        public bool Archived { get; set; }
    }
}