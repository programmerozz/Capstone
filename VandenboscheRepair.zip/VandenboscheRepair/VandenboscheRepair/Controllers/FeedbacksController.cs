﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;

namespace VandenboscheRepair.Controllers
{
    public class FeedbacksController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }

        public ActionResult OldReview()
        {
            if (Validated())
            {
                return View(db.Feedbacks.ToList().FindAll(x => x.markRead == true));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Feedbacks
        public ActionResult Index()
        {
            if (Validated())
            {
                return View(db.Feedbacks.ToList().FindAll(x=>x.markRead==false));
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Feedbacks/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Feedback feedback = db.Feedbacks.Find(id);
                if (feedback == null)
                {
                    return HttpNotFound();
                }
                return View(feedback);
            }
            else {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Feedbacks/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Title,Rating,Comments")] Feedback feedback)
        {
            if (ModelState.IsValid)
            {
                db.Feedbacks.Add(feedback);
                db.SaveChanges();
                return RedirectToAction("Index","Home");
            }
            return View(feedback);
        }

        // GET: Feedbacks/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Feedback feedback = db.Feedbacks.Find(id);
                if (feedback == null)
                {
                    return HttpNotFound();
                }
                return View(feedback);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Feedbacks/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Title,Rating,Comments,markRead")] Feedback feedback)
        {
            if (Validated())
            {
                if (checkAdminStatus())
                {
                    if (ModelState.IsValid)
                    {
                        db.Entry(feedback).State = EntityState.Modified;
                        db.SaveChanges();
                        Session["numberFeedbacks"] = db.Feedbacks.ToList().FindAll(x => x.markRead == false).Count;
                        return RedirectToAction("Index");
                    }
                    return View(feedback);
                }
                else
                {
                    Session["error401"] = "You do not have access to edit this feedback";
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Feedbacks/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Feedback feedback = db.Feedbacks.Find(id);
                if (feedback == null)
                {
                    return HttpNotFound();
                }
                return View(feedback);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Feedbacks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                if (checkAdminStatus())
                {
                    Feedback feedback = db.Feedbacks.Find(id);
                    db.Feedbacks.Remove(feedback);
                    db.SaveChanges();
                    Session["numberFeedbacks"] = db.Feedbacks.ToList().FindAll(x => x.markRead == false).Count;
                    return RedirectToAction("Index");
                }
                else
                {
                    Session["error401"] = "You do not have access to delete a customer feedback";
                    return RedirectToAction("Index");
                }
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        private bool checkAdminStatus()
        {
            Admin adm = (Admin)Session["adminLoggedIn"];
            if(adm == null)
            {
                return false;
            }
            else
            {
                if (adm.Type == "Manager")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
