﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace VandenboscheRepair.Models
{
    [MetadataType(typeof(AdminMetaData))]
    public partial class Admin
    {

    }

    [MetadataType(typeof(JobMetaData))]
    public partial class Job
    {

    }

    [MetadataType(typeof(CustomerMetaData))]
    public partial class Customer
    {

    }

    [MetadataType(typeof(AppointmentMetaData))]
    public partial class Appointment
    {


    }
}