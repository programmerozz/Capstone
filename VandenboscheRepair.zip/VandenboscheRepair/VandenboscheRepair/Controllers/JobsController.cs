﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using VandenboscheRepair.Models;

namespace VandenboscheRepair.Controllers
{
    public class JobsController : Controller
    {
        private VandenboscheDBEntities db = new VandenboscheDBEntities();

        private bool Validated()
        {
            if (Session["adminLoggedIn"] == null)
            {
                Session["invalidLoginAttempt"] = true;
                return false;
            }
            else
            {
                try
                {
                    Admin ad = (Admin)Session["adminLoggedIn"];
                    return true;
                }
                catch (Exception exp)
                {
                    return false;
                }
            }
        }


        public ActionResult Receipt(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Job job = db.Jobs.Find(id);
                if (job == null)
                {
                    return HttpNotFound();
                }
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Jobs
        public ActionResult Index()
        {
            if (Validated())
            {
                var jobs = db.Jobs.Include(j => j.Customer);
                return View(jobs.ToList());
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Jobs/Details/5
        public ActionResult Details(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Job job = db.Jobs.Find(id);
                if (job == null)
                {
                    return HttpNotFound();
                }
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Jobs/Create
        public ActionResult Create()
        {
            if (Validated())
            {
                ViewBag.Customers_Id = new SelectList((from c in db.Customers.ToList()
                    select new
                    {
                        Id = c.Id,
                        FullName = c.FirstName + " - " + c.Phone
                    }),
                "Id",
                "FullName",
                null);
                try {
                    Session["newCustId"] = "VBJ" + (db.Jobs.Max(x => x.Id) + 1);
                }
                catch(InvalidOperationException exp)
                {
                    //first database value
                    Session["newCustId"] = "VBJ1";
                }
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Jobs/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,JobID,ItemType,JobType,Status,DatePromised,Instructions,Deposit,SubTotal,HstGst,Pst,DatePickedUp,DateReceived,Customers_Id")] Job job, [Bind(Include = "file")]HttpPostedFileBase file)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    try {
                        //find and add admin
                        Admin ad = (Admin)Session["adminLoggedIn"];
                        job.Admins = db.Admins.Find(ad.Id);
                        //find and add image
                        if(file != null)
                        {
                            if (file.ContentType.Split('/')[0] == "image")
                            {
                                string fileName = System.IO.Path.GetFileName(job.JobID + "." + file.ContentType.Split('/')[1]);
                                string path = System.IO.Path.Combine(Server.MapPath("~/Images"), fileName);
                                // file is uploaded
                                file.SaveAs(path);
                                //save file name
                                job.Image = path;
                            }
                            else
                            {
                                try
                                {
                                    Session["newCustId"] = "VBJ" + (db.Jobs.Max(x => x.Id) + 1);
                                }
                                catch (InvalidOperationException exp)
                                {
                                    //first database value
                                    Session["newCustId"] = "VBJ1";
                                }
                                Session["validJobImage"] = "flag";
                                ViewBag.Customers_Id = new SelectList((from c in db.Customers.
                                                                       ToList() select new{
                                Id = c.Id,
                                FullName = c.FirstName + " - " + c.Phone
                                }),
                                "Id",
                                "FullName",
                                null);
                                return View(job);
                            }
                        }
                        db.Jobs.Add(job);
                        db.SaveChanges();
                        return RedirectToAction("Details", new { id = job.Id });
                    }
                    catch (Exception e)
                    {
                        return RedirectToAction("Error");
                    }
                }
                try
                {
                    Session["newCustId"] = "VBJ" + (db.Jobs.Max(x => x.Id) + 1);
                }
                catch (InvalidOperationException exp)
                {
                    //first database value
                    Session["newCustId"] = "VBJ1";
                }
                ViewBag.Customers_Id = new SelectList((from c in db.Customers.ToList()
                    select new
                    {
                        Id = c.Id,
                        FullName = c.FirstName + " - " + c.Phone
                    }),
                "Id",
                "FullName",
                null);
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        public ActionResult Error()
        {
            if (Validated())
            {
                return View();
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Jobs/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Job job = db.Jobs.Find(id);
                if (job == null)
                {
                    return HttpNotFound();
                }
                List<Customer> tempCustList =  db.Customers.ToList();
                Customer cust = tempCustList.Find(x => x.Id == ((from j in db.Jobs where j.Id == id select j.Customers_Id).FirstOrDefault()));
                tempCustList.Remove(cust);
                tempCustList.Insert(0,cust);
                ViewBag.Customers_Id = new SelectList((from c in tempCustList
                                                       select new
                                                       {
                                                           Id = c.Id,
                                                           FullName = c.FirstName + " - " + c.Phone
                                                       }),
                "Id",
                "FullName",
                null);
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Jobs/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,JobID,ItemType,JobType,Status,DatePromised,Instructions,Deposit,SubTotal,HstGst,Pst,DatePickedUp,DateReceived,Customers_Id,Image")] Job job, [Bind(Include = "file")]HttpPostedFileBase file)
        {
            if (Validated())
            {
                if (ModelState.IsValid)
                {
                    if (file != null)
                    {
                        if (file.ContentType.Split('/')[0] == "image")
                        {
                            //try deleting the file. If the file does not exists, it will fail
                            try
                            {
                                System.IO.File.Delete(job.Image);
                            }
                            catch(Exception excp) { }
                            //try saving the file. It will fail if the job did not had any image to start off with
                            try
                            {
                                file.SaveAs(job.Image);
                            }
                            catch(Exception excp)
                            {
                                string fileName = System.IO.Path.GetFileName(job.JobID + "." + file.ContentType.Split('/')[1]);
                                string path = System.IO.Path.Combine(Server.MapPath("~/Images"), fileName);
                                file.SaveAs(path);
                                job.Image = path;
                            }
                        }
                        else
                        {
                            Session["validJobImage"] = "flag";
                            return View(job);
                        }
                    }
                    db.Entry(job).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                List<Customer> tempCustList = db.Customers.ToList();
                Customer cust = tempCustList.Find(x => x.Id == ((from j in db.Jobs where j.Id == job.Id select j.Customers_Id).FirstOrDefault()));
                tempCustList.Remove(cust);
                tempCustList.Insert(0, cust);
                ViewBag.Customers_Id = new SelectList((from c in tempCustList
                                                       select new
                                                       {
                                                           Id = c.Id,
                                                           FullName = c.FirstName + " - " + c.Phone
                                                       }),
                "Id",
                "FullName",
                null);
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // GET: Jobs/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Validated())
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Job job = db.Jobs.Find(id);
                if (job == null)
                {
                    return HttpNotFound();
                }
                return View(job);
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        // POST: Jobs/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Validated())
            {
                Job job = db.Jobs.Find(id);
                //try deleting the file. If the file does not exists, it will fail
                try
                {
                    System.IO.File.Delete(job.Image);
                }
                catch (Exception excp) { }
                db.Jobs.Remove(job);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return Redirect("/Home/AdminAuthentication");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
