Use Case implemented for this Iteration:
Create Admin
Create Customer
Create Jobs

Link to reach the website for Vandenbosche repair is http://waynetech.azurewebsites.net/
Repository Link :https://arslano.visualstudio.com/VandenboscheRepair/_git/VandenboscheRepair

Below links provide the information from where you can see the code for the entitied added.
Create Admin	
	Views
	/Views/Admins/Index.cshtml		View for Dashboard
	/Views/Admins/Manage.cshtml		View for Display Customers
	/Views/Admns/Create.cshtml		View for Create Admin
	/Views/Admns/Delete.cshtml		View for Delete Admin
	/Views/Admns/Details.cshtml		View for Display Individual Admin
	/Views/Admns/Edit.cshtml		View for Edit Admin
	Controllers
	/Controllers/AdminsController.cs
        
Create Customer 
	Views
	/Views/Customers/Index.cshtml		View for Display Customers
	/Views/Customers/Create.cshtml		View for Add Customer
	/Views/Customers/Delete.cshtml		View for Delete Customer
	/Views/Customers/Details.cshtml		View for Display individual Customer
	/Views/Customers/Edit.cshtml		View for Edit Customer
	Controllers
	/Controllers/CustomersController.cs
       
Create Jobs
	Views 
	/Views/Jobs/Index.cshtml		View for display all Jobs
	/Views/Jobs/Create.cshtml		View for Add Job
	/Views/Jobs/Delete.cshtml		View for Delete Job
	/Views/Jobs/Details.cshtml		View for Job Details
	/Views/Jobs/Edit.cshtml			View for Edit Job
	Controllers
	/Controllers/JobsController.cs
        
Model folder has the database created in it and has the script file with the database script 
It shows all the tables and their associations which each other and mapped as per the requirement 

Few Keypoints:
1. This application do add the value to the customers as it make the work very easy for them
2. Using the bootstrap helped us to make the website work even on the phone
3. We have hosted it on the Azure cloud so it meets the capability to host the code
4. Application runs bug free
5. All coding standars and security measures has been taken off

Framework used:
Entity Framework
Bootstrap
Jquery
DataTables


RECENT UPDATES

About page, login page, home page and general css has been changed.
Job ID automated.

READ ME FILE FOR OCT -07-2016 
Use Case implemented for this Iteration:
CREATE JOBS

Link to reach the  team foundation Server repository to access the code 
https://arslano.visualstudio.com/VandenboscheRepair/_git/VandenboscheRepair

And branch name is Css

Create Jobs
	Views
	/Views/Jobs/Index.cshtml		View to display Job
	/Views/Jobs/Create.cshtml		View to create new job
	/Views/Jobs/Delete.cshtml		View to delete job
	/Views/Jobs/Details.cshtml		View to display the jobs
	/Views/Jobs/Edit.cshtml		        View to edit job
	Controllers
	/Controllers/JobsController.cs
       
        
Model folder has the database created in it and has the script file with the database script 
It shows all the tables and their associations which each other and mapped as per the requirement 

Few Key points:
1. This application do add the value to the customers as it is efficient and saves time 
2. Using the bootstrap helped us to make the website work even on the phone
3. We have hosted it on the Azure cloud so it meets the capability to host the code
4. Application runs bug free
5. All coding standards and security measures has been taken off

Framework used:
Entity Framework
Bootstrap
Jquery
DataTables

